
// Shared UI logic
const $ = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));

const LT = {
  fmt(n){ return `$${(n||0).toFixed(2)}`; },
  notify(msg){ alert(msg); },

  // Home
  renderFeatured(){
    const wrap = document.getElementById('featured'); if(!wrap) return;
    const prods = LTStore.get(LTKEY.products, []).slice(0,3);
    wrap.innerHTML = prods.map(p => `
      <div class="card" style="grid-column:span 4">
        <img src="${p.img}" alt="${p.name}" style="width:100%;height:220px;object-fit:cover"/>
        <div class="body">
          <span class="badge">${p.category}</span>
          <h3>${p.name}</h3>
          <div class="row" style="justify-content:space-between;align-items:center">
            <div class="price">from ${LT.fmt(p.price)}</div>
            <button class="btn" onclick="LT.openConfig('${p.id}')">Configure</button>
          </div>
        </div>
      </div>
    `).join('');
    // subtitle
    const sub = LTStore.get(LTKEY.settings, {}).subtitle;
    const subEl = document.querySelector('.hero .sub'); if(sub && subEl) subEl.textContent = sub;
  },

  // All Grillz
  loadFilters(){
    const select = document.getElementById('filterCategory'); if(!select) return;
    const cats = [...new Set(LTStore.get(LTKEY.products, []).map(p=>p.category))].sort();
    select.innerHTML = '<option value="">All Categories</option>' + cats.map(c=>`<option>${c}</option>`).join('');
  },
  renderProducts(){
    const grid = document.getElementById('products'); if(!grid) return;
    const q = (document.getElementById('search')?.value||'').toLowerCase();
    const cat = (document.getElementById('filterCategory')?.value||'');
    let prods = LTStore.get(LTKEY.products, []).filter(p => p.active);
    if(q) prods = prods.filter(p => p.name.toLowerCase().includes(q) || p.category.toLowerCase().includes(q));
    if(cat) prods = prods.filter(p => p.category===cat);
    if(!prods.length){ grid.innerHTML = '<p class="muted">No products found.</p>'; return; }
    grid.innerHTML = prods.map(p => `
      <div class="card" style="grid-column:span 4">
        <img src="${p.img}" alt="${p.name}" style="width:100%;height:220px;object-fit:cover"/>
        <div class="body">
          <span class="badge">${p.category}</span>
          <h3>${p.name}</h3>
          <p class="muted">${p.desc||''}</p>
          <div class="row" style="justify-content:space-between;align-items:center">
            <div class="price">from ${LT.fmt(p.price)}</div>
            <button class="btn" onclick="LT.openConfig('${p.id}')">Configure</button>
          </div>
        </div>
      </div>
    `).join('');
  },

  openConfig(id){
    const p = LTStore.get(LTKEY.products, []).find(x=>x.id===id);
    const modal = document.getElementById('configModal'); if(!modal) return;
    const body = document.getElementById('configBody');
    body.innerHTML = `
      <p><strong>${p.name}</strong></p>
      <div class="grid" style="grid-template-columns:repeat(2,1fr)">
        <div>
          <label>Metal</label>
          <select id="cfg_metal">
            <option>10K Gold</option>
            <option>14K Gold</option>
            <option>18K Gold</option>
            <option>Silver</option>
            <option>Rose Gold</option>
            <option>Gold Plated</option>
          </select>
        </div>
        <div>
          <label>Tooth Count</label>
          <select id="cfg_teeth">
            <option value="1">1</option><option value="2">2</option><option value="4">4</option>
            <option value="6">6</option><option value="8">8</option><option value="12">12</option>
          </select>
        </div>
      </div>
      <label>Notes (optional)</label>
      <textarea id="cfg_notes" class="input" rows="3" placeholder="Any special request..."></textarea>
      <div class="row" style="margin-top:10px;justify-content:space-between">
        <div class="muted">Price updates in cart.</div>
        <button class="btn" onclick="LT.addToCart('${p.id}')">Add to Cart</button>
      </div>
    `;
    modal.classList.remove('hidden');
  },
  closeConfig(){ document.getElementById('configModal')?.classList.add('hidden'); },

  addToCart(id){
    const p = LTStore.get(LTKEY.products, []).find(x=>x.id===id);
    const metal = $('#cfg_metal')?.value || '10K Gold';
    const teeth = parseInt($('#cfg_teeth')?.value || '1',10);
    const notes = $('#cfg_notes')?.value || '';
    const priceFactor = (m)=>({ '10K Gold':1, '14K Gold':1.15, '18K Gold':1.35, 'Silver':0.75, 'Rose Gold':1.1, 'Gold Plated':0.5 }[m]||1);
    const item = { id: crypto.randomUUID(), productId: p.id, name:p.name, img:p.img, category:p.category,
      metal, teeth, notes, unitPrice: p.price * priceFactor(metal), total: p.price * priceFactor(metal) * teeth };
    const cart = LTStore.get(LTKEY.cart, []); cart.push(item); LTStore.set(LTKEY.cart, cart);
    LT.notify('Added to cart.');
    LT.closeConfig();
  },

  // Cart
  renderCart(){
    const box = document.getElementById('cartItems'); if(!box) return;
    const cart = LTStore.get(LTKEY.cart, []);
    if(!cart.length){ box.innerHTML = '<p class="muted">Your cart is empty.</p>'; $('#cartTotal').textContent = LT.fmt(0); return; }
    let total = 0;
    box.innerHTML = cart.map(it=>{
      total += it.total;
      return `
        <div class="card">
          <div class="body">
            <div class="row" style="justify-content:space-between">
              <div class="row" style="gap:14px">
                <img src="${it.img}" style="width:72px;height:72px;object-fit:cover;border-radius:10px"/>
                <div>
                  <strong>${it.name}</strong><br/>
                  <small class="muted">${it.category} • ${it.metal} • ${it.teeth} teeth</small>
                </div>
              </div>
              <div class="row">
                <div class="price">${LT.fmt(it.total)}</div>
                <button class="btn ghost" onclick="LT.removeCart('${it.id}')">Remove</button>
              </div>
            </div>
            ${it.notes ? `<small class="muted">Notes: ${it.notes}</small>`:''}
          </div>
        </div>
      `;
    }).join('');
    $('#cartTotal').textContent = LT.fmt(total);
  },
  removeCart(id){
    let cart = LTStore.get(LTKEY.cart, []);
    cart = cart.filter(x=>x.id!==id);
    LTStore.set(LTKEY.cart, cart);
    LT.renderCart();
  },
  clearCart(){ LTStore.set(LTKEY.cart, []); LT.renderCart(); },
  checkout(){
    const email = prompt('Enter your email to send the cart to us:');
    if(!email) return;
    const cart = LTStore.get(LTKEY.cart, []);
    const messages = LTStore.get(LTKEY.messages, []);
    messages.push({
      id: crypto.randomUUID(),
      email, name: email.split('@')[0],
      text: `Cart Inquiry: ${cart.map(c=>`${c.name} [${c.metal}, ${c.teeth}]`).join('; ')}`,
      from:'user', ts: Date.now()
    });
    LTStore.set(LTKEY.messages, messages);
    LT.notify('Sent! We will reply in Messenger.');
  },

  // Contact & Custom forms
  submitContact(e){
    e.preventDefault();
    const name = $('#c_name').value, email = $('#c_email').value, msg = $('#c_msg').value;
    const messages = LTStore.get(LTKEY.messages, []);
    messages.push({id: crypto.randomUUID(), email, name, text: msg, from:'user', ts: Date.now()});
    LTStore.set(LTKEY.messages, messages);
    e.target.reset();
    LT.notify('Message sent! Check Messenger for replies.');
    return false;
  },
  submitCustomOrder(e){
    e.preventDefault();
    const name = $('#co_name').value, email = $('#co_email').value, desc = $('#co_desc').value;
    const messages = LTStore.get(LTKEY.messages, []);
    messages.push({id: crypto.randomUUID(), email, name, text: `Custom Order: ${desc}`, from:'user', ts: Date.now()});
    LTStore.set(LTKEY.messages, messages);
    e.target.reset();
    LT.notify('Request sent! We will reply in Messenger.');
    return false;
  },

  // Reviews
  renderReviews(){
    const box = document.getElementById('reviews'); if(!box) return;
    const revs = LTStore.get(LTKEY.reviews, []).filter(r=>r.status==='approved');
    if(!revs.length){ box.innerHTML = '<p class="muted">No reviews yet.</p>'; return; }
    box.innerHTML = revs.map(r=>`
      <div class="card" style="grid-column:span 6">
        <div class="body">
          <div class="row" style="justify-content:space-between">
            <strong>${r.name}</strong>
            <span class="badge">⭐ ${r.rating}</span>
          </div>
          <p>${r.text}</p>
        </div>
      </div>
    `).join('');
  },
  submitReview(e){
    e.preventDefault();
    const name = $('#r_name').value, rating = parseInt($('#r_rating').value,10), text = $('#r_text').value;
    const revs = LTStore.get(LTKEY.reviews, []);
    revs.push({id: crypto.randomUUID(), name, rating, text, status:'pending'});
    LTStore.set(LTKEY.reviews, revs);
    e.target.reset();
    LT.notify('Review submitted. Pending approval.');
    return false;
  },

  // Messenger
  loadThread(){
    const email = $('#m_email').value.trim(); if(!email) return;
    const msgs = LTStore.get(LTKEY.messages, []).filter(m=>m.email===email).sort((a,b)=>a.ts-b.ts);
    const body = $('#threadBody');
    if(!msgs.length){ body.innerHTML = '<small class="muted">No messages yet.</small>'; return; }
    body.innerHTML = msgs.map(m=>`
      <div class="row" style="justify-content:${m.from==='user'?'flex-end':'flex-start'}">
        <div class="badge" style="max-width:70%">${m.text}</div>
      </div>
    `).join('');
  },
  sendMessage(e){
    e.preventDefault();
    const email = $('#m_email').value.trim(); if(!email) return false;
    const text = $('#m_text').value.trim(); if(!text) return false;
    const messages = LTStore.get(LTKEY.messages, []);
    messages.push({id: crypto.randomUUID(), email, name: email.split('@')[0], text, from:'user', ts: Date.now()});
    LTStore.set(LTKEY.messages, messages);
    $('#m_text').value='';
    LT.loadThread();
    return false;
  },

  // Admin auth
  adminLogin(){
    const pass = $('#adminPass').value;
    const a = LTStore.get(LTKEY.admin, {password:'admin123'});
    if(pass===a.password){
      a.authed = true; LTStore.set(LTKEY.admin, a);
      $('#adminLogin').classList.add('hidden');
      $('#adminApp').classList.remove('hidden');
      LT.showTab('products'); LT.refreshTables();
    } else alert('Wrong password');
  },
  adminLogout(){
    const a = LTStore.get(LTKEY.admin, {}); a.authed=false; LTStore.set(LTKEY.admin, a);
    location.reload();
  },
  setPassword(){
    const np = $('#set_pass').value.trim(); if(!np) return;
    const a = LTStore.get(LTKEY.admin, {}); a.password=np; LTStore.set(LTKEY.admin, a);
    alert('Password updated.');
  },
  setSubtitle(){
    const s = $('#set_sub').value;
    const st = LTStore.get(LTKEY.settings, {}); st.subtitle = s; LTStore.set(LTKEY.settings, st);
    alert('Saved. Check Home page.');
  },

  showTab(name){
    ['products','reviews','messages','settings'].forEach(n=>{
      const el = document.getElementById('tab_'+n);
      if(el) el.classList.toggle('hidden', n!==name);
    });
  },

  // Admin tables
  refreshTables(){
    // products
    const p = LTStore.get(LTKEY.products, []);
    const pT = $('#prodTable');
    pT.innerHTML = '<tr><th>Name</th><th>Category</th><th>Price</th><th>Active</th><th></th></tr>' + 
      p.map(x=>`<tr>
        <td>${x.name}</td><td>${x.category}</td><td>${LT.fmt(x.price)}</td><td>${x.active?'Yes':'No'}</td>
        <td>
          <button class="btn ghost" onclick="LT.editProduct('${x.id}')">Edit</button>
          <button class="btn danger" onclick="LT.deleteProduct('${x.id}')">Delete</button>
        </td>
      </tr>`).join('');

    // reviews
    const r = LTStore.get(LTKEY.reviews, []);
    const rT = $('#revTable');
    rT.innerHTML = '<tr><th>Name</th><th>Rating</th><th>Text</th><th>Status</th><th></th></tr>' +
      r.map(x=>`<tr>
        <td>${x.name}</td><td>${x.rating}</td><td>${x.text}</td><td>${x.status}</td>
        <td>
          ${x.status!=='approved' ? `<button class="btn ok" onclick="LT.approveReview('${x.id}')">Approve</button>`:''}
          <button class="btn danger" onclick="LT.deleteReview('${x.id}')">Delete</button>
        </td>
      </tr>`).join('');

    // messages
    const m = LTStore.get(LTKEY.messages, []);
    const byEmail = {};
    m.forEach(x=>{ byEmail[x.email] = byEmail[x.email]||[]; byEmail[x.email].push(x); });
    const rows = Object.entries(byEmail).map(([email, arr])=>{
      const last = arr.sort((a,b)=>b.ts-a.ts)[0];
      return `<tr>
        <td>${email}</td><td>${(new Date(last.ts)).toLocaleString()}</td><td>${last.text}</td>
        <td><button class="btn" onclick="LT.reply('${email}')">Reply</button></td>
      </tr>`;
    }).join('');
    const mT = $('#msgTable');
    mT.innerHTML = '<tr><th>Email</th><th>Last</th><th>Snippet</th><th></th></tr>' + rows;
  },

  approveReview(id){
    const r = LTStore.get(LTKEY.reviews, []);
    const i = r.findIndex(x=>x.id===id); if(i>-1){ r[i].status='approved'; LTStore.set(LTKEY.reviews, r); LT.refreshTables(); alert('Approved'); }
  },
  deleteReview(id){
    let r = LTStore.get(LTKEY.reviews, []); r = r.filter(x=>x.id!==id); LTStore.set(LTKEY.reviews, r); LT.refreshTables();
  },

  reply(email){
    const text = prompt('Reply to '+email+':'); if(!text) return;
    const m = LTStore.get(LTKEY.messages, []);
    m.push({id: crypto.randomUUID(), email, name:'Admin', text:'Admin: '+text, from:'admin', ts: Date.now()});
    LTStore.set(LTKEY.messages, m);
    alert('Sent');
    LT.refreshTables();
  },

  openProductForm(editId){
    $('#productForm').classList.remove('hidden');
    const isEdit = !!editId;
    $('#pf_title').textContent = isEdit ? 'Edit Product' : 'New Product';
    if(isEdit){
      const p = LTStore.get(LTKEY.products, []).find(x=>x.id===editId);
      $('#pf_name').value=p.name; $('#pf_cat').value=p.category; $('#pf_price').value=p.price;
      $('#pf_img').value=p.img; $('#pf_desc').value=p.desc; $('#pf_active').value=p.active;
      $('#productForm').dataset.editId = editId;
    } else {
      $('#pf_name').value=''; $('#pf_cat').value=''; $('#pf_price').value='';
      $('#pf_img').value=''; $('#pf_desc').value=''; $('#pf_active').value='true';
      delete $('#productForm').dataset.editId;
    }
  },
  closeProductForm(){ $('#productForm').classList.add('hidden'); },
  editProduct(id){ LT.openProductForm(id); },
  saveProduct(){
    const name = $('#pf_name').value.trim();
    const category = $('#pf_cat').value.trim();
    const price = parseFloat($('#pf_price').value||'0');
    const img = $('#pf_img').value.trim();
    const desc = $('#pf_desc').value.trim();
    const active = $('#pf_active').value==='true';
    if(!name || !category || !price || !img){ alert('Please fill all required fields.'); return; }
    const ps = LTStore.get(LTKEY.products, []);
    const editId = $('#productForm').dataset.editId;
    if(editId){
      const i = ps.findIndex(x=>x.id===editId);
      ps[i] = {...ps[i], name, category, price, img, desc, active};
    } else {
      ps.push({id: crypto.randomUUID(), name, category, price, img, desc, active});
    }
    LTStore.set(LTKEY.products, ps);
    LT.closeProductForm(); LT.refreshTables(); LT.loadFilters(); LT.renderProducts(); LT.renderFeatured();
  },
  deleteProduct(id){
    let ps = LTStore.get(LTKEY.products, []); ps = ps.filter(x=>x.id!==id); LTStore.set(LTKEY.products, ps);
    LT.refreshTables(); LT.loadFilters(); LT.renderProducts(); LT.renderFeatured();
  }
};

// Auto-init per page
window.addEventListener('DOMContentLoaded', () => {
  LT.renderFeatured();
  LT.loadFilters(); LT.renderProducts();
  LT.renderCart();
  LT.renderReviews();

  // If admin authed from previous
  const a = LTStore.get(LTKEY.admin, {});
  if(a.authed){ document.getElementById('adminLogin')?.classList.add('hidden'); document.getElementById('adminApp')?.classList.remove('hidden'); LT.showTab('products'); LT.refreshTables(); }
});
