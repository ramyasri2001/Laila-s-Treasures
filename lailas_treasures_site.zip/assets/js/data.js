
// Lightweight storage helpers & seed data
const LTKEY = {
  products: 'lt_products',
  reviews: 'lt_reviews',
  messages: 'lt_messages',
  cart: 'lt_cart',
  settings: 'lt_settings',
  admin: 'lt_admin'
};

const LTStore = {
  get(k, d){ try{ return JSON.parse(localStorage.getItem(k)) ?? d }catch{ return d }},
  set(k, v){ localStorage.setItem(k, JSON.stringify(v)); },
  seed(){
    if(!LTStore.get(LTKEY.products)){
      LTStore.set(LTKEY.products, [
        {id: crypto.randomUUID(), name:'Open Face (Top Single)', category:'Open Face', price:149, img:'https://images.unsplash.com/photo-1606313564200-e75d5e30476a?q=80&w=800&auto=format&fit=crop', desc:'Classic open-face single tooth.', active:true},
        {id: crypto.randomUUID(), name:'Solid Gold (Bottom 6)', category:'Solid', price:199, img:'https://images.unsplash.com/photo-1516223725307-6f76b31638d1?q=80&w=800&auto=format&fit=crop', desc:'Solid set, base price per tooth.', active:true},
        {id: crypto.randomUUID(), name:'Diamond Cut (Top 4)', category:'Diamond Cut', price:259, img:'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=800&auto=format&fit=crop', desc:'Shimmering diamond-cut style.', active:true}
      ]);
    }
    if(!LTStore.get(LTKEY.reviews)){
      LTStore.set(LTKEY.reviews, [
        {id: crypto.randomUUID(), name:'Aaliyah', rating:5, text:'Perfect fit and shine!', status:'approved'},
        {id: crypto.randomUUID(), name:'Jordan', rating:4, text:'Great quality. Fast communication.', status:'approved'}
      ]);
    }
    if(!LTStore.get(LTKEY.messages)){ LTStore.set(LTKEY.messages, []); }
    if(!LTStore.get(LTKEY.cart)){ LTStore.set(LTKEY.cart, []); }
    if(!LTStore.get(LTKEY.settings)){ LTStore.set(LTKEY.settings, {subtitle:'Choose your metal, style, and tooth count.'}); }
    if(!LTStore.get(LTKEY.admin)){ LTStore.set(LTKEY.admin, {password:'admin123', authed:false}); }
  }
};

LTStore.seed();
